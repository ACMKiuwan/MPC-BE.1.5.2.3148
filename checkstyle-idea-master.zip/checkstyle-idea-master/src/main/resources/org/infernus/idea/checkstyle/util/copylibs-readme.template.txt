This folder contains libraries copied from the "{0}" project.
It is managed by the {1} IDE plugin.
Do not modify this folder while the IDE is running.
When the IDE is stopped, you may delete this folder at any time. It will be recreated as needed.
In order to prevent the {1} IDE plugin from creating this folder,
uncheck the "Copy libraries from project directory" option in the {1} settings dialog.

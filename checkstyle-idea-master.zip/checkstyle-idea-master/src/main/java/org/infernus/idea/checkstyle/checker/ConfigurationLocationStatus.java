package org.infernus.idea.checkstyle.checker;

public enum ConfigurationLocationStatus {

    PRESENT,
    NOT_PRESENT,
    BLACKLISTED

}

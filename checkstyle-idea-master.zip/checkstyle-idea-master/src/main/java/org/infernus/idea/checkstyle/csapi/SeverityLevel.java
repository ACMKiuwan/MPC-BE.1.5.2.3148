package org.infernus.idea.checkstyle.csapi;

/**
 * Checkstyle violation severity levels supported by this plugin.
 */
public enum SeverityLevel {
    Ignore, Info, Warning, Error;
}

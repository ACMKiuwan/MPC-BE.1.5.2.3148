package org.infernus.idea.checkstyle;

public interface ConfigurationListener {

    void configurationChanged();

}

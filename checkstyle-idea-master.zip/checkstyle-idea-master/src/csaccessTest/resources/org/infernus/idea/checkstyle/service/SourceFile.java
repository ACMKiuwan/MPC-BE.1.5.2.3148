package org.infernus.idea.checkstyle.service;

/**
 * An example source file used for triggering Checkstyle scans in unit tests.
 */
public class SourceFile
{
    public void method() {
        // does not matter
    }
}

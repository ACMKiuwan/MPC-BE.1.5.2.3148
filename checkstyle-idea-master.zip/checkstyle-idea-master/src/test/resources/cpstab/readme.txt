This file should be named as in TempDirProvider.README_FILE.

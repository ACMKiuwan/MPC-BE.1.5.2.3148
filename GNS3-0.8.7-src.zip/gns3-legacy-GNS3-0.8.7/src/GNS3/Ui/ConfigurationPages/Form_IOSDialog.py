# vim: expandtab ts=4 sw=4 sts=4:
# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Form_IOSDialog.ui'
#
# Created: Mon Jun 27 18:04:24 2011
#      by: PyQt4 UI code generator 4.7.3
#
# WARNING! All changes made in this file will be lost!


`/var/tmp $ javac YOUR_FILE.java`:

```
[[PLACE YOUR OUTPUT HERE]]
```

`/var/tmp $ cat YOUR_FILE.java`:

```
[[PLACE YOU OUTPUT HERE]]
```

`/var/tmp $ cat config.xml`:

```
[[PLACE YOUR OUTPUT HERE]]
```

`/var/tmp $ java -Duser.language=en -Duser.country=US -jar checkstyle-X.XX-all.jar -c config.xml YOUR_FILE.java`:

```
[[PLACE YOUR OUTPUT HERE]]
```

---------------

Describe what you expect in detail.

--------------

Still not clear ??? - see example - http://checkstyle.sourceforge.net/report_issue.html#How_to_report_a_bug

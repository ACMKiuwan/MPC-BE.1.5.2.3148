package xdman.ui.components;

import javax.swing.JScrollBar;

public class DarkScrollBar extends JScrollBar {
	public DarkScrollBar() {
		// TODO Auto-generated constructor stub
	}

	public DarkScrollBar(int orientation) {
		super(orientation);
	}
}

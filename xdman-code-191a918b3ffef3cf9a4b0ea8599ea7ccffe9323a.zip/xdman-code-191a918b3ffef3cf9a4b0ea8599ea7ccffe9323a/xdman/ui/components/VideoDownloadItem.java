package xdman.ui.components;

public class VideoDownloadItem {
	public String title, desc;
}

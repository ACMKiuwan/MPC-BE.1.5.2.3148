package xdman.ui.res;

import javax.swing.Icon;
import javax.swing.JButton;

public class CustomButton extends JButton {
	private static final long serialVersionUID = 6378409011977437191L;

	public CustomButton() {
		// TODO Auto-generated constructor stub
	}

	public CustomButton(Icon icon) {
		super(icon);
	}

	public CustomButton(String text) {
		super(text);
	}
}

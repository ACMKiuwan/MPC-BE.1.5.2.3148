package xdman.network.http;

import java.io.IOException;

public class JavaClientRequiredException extends IOException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -54189948361748662L;

}

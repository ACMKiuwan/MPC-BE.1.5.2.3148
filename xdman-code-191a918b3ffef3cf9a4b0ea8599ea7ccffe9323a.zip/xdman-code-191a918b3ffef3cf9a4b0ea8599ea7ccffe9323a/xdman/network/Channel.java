package xdman.network;

public abstract class Channel {
	private volatile long length, startOff, downloaded;
	private byte[] buf;
	private volatile boolean stopFlag;

	public abstract boolean open();

	protected Channel() {
		buf = new byte[8192];
	}
}

package xdman.network;

import xdman.network.http.WebProxy;

public class AutoProxyResolver {
	public static WebProxy resolve(String url) {
		return null;
	}
}

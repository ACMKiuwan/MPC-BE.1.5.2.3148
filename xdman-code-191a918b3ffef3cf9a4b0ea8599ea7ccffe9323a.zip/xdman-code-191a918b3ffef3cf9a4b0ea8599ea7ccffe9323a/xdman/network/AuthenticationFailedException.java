package xdman.network;

import java.io.IOException;

public class AuthenticationFailedException extends IOException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7942287137125196959L;

}

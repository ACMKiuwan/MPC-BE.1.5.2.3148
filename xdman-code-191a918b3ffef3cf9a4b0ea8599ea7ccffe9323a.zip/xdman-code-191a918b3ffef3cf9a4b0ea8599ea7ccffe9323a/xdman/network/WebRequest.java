package xdman.network;

public abstract class WebRequest implements Runnable {

	protected abstract boolean open();

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}

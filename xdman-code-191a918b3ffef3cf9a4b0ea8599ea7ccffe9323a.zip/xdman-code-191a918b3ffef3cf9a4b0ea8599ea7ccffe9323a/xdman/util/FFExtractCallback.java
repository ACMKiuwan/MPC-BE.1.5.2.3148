package xdman.util;

public interface FFExtractCallback {
	public void stop();
}

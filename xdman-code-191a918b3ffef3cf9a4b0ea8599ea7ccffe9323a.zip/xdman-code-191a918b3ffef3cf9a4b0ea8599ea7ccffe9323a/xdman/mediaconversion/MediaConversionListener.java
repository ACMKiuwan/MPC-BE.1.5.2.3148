package xdman.mediaconversion;

public interface MediaConversionListener {
	public void progress(int progress);
}

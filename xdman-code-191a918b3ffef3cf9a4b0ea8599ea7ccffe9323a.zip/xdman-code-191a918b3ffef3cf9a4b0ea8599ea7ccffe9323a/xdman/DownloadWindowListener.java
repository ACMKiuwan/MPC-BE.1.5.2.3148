package xdman;

public interface DownloadWindowListener {
	public void pauseDownload(String id);

	public void hidePrgWnd(String id);
}

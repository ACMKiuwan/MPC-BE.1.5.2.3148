libbzip2
http://bzip.org/1.0.6/bzip2-1.0.6.tar.gz
Version 1.0.6 (20/09/2010)

#!/bin/sh
# http://pasdoc.sourceforge.net
pasdoc --marker en --output doc/en/dev-help --define UNIX --source units-doc-unix.txt
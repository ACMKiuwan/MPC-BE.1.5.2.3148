Virtual Tree View from Lazarus CCR
https://lazarus-ccr.svn.sourceforge.net/svnroot/lazarus-ccr/components/virtualtreeview-new/branches/4.8
Rev. 2200

Some modifications done for Double Commander (see doublecmd.diff).

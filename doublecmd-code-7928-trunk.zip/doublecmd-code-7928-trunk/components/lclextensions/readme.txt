lclextensions v0.4
http://code.google.com/p/luipack/

Some modifications done so that it only compiles VirtualTreeView.
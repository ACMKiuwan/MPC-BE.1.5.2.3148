CRC / HASH / HMAC
http://www.wolfgang-ehrhardt.de/crchash_en.html
crc_hash_2016-05-01.zip

Some modifications done for Double Commander (see doublecmd.diff).

Before create packages (before run create_packages.bat) copy in this directory third-party libraries:
- unrar.dll - needed for unrar plugin